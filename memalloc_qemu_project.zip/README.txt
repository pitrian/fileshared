
# MiniOS with Custom Memory Allocator

## 📦 Cấu trúc thư mục:
- `bootloader.asm` - Bootloader đơn giản để khởi động OS
- `kernel.c` - Chứa hàm kmain() và sử dụng bộ cấp phát bộ nhớ
- `memalloc.c`, `memalloc.h` - Bộ cấp phát bộ nhớ tự xây
- `screen.c`, `screen.h` - Hàm hiển thị văn bản ra màn hình
- `linker.ld`, `kernel_entry.asm` - Các thành phần khởi động kernel
- `Makefile` - Dùng để biên dịch và chạy bằng QEMU

## 🚀 Cách chạy
1. Mở Terminal trong thư mục này
2. Chạy lần lượt:
```bash
make clean
make run
```

QEMU sẽ hiện màn hình chạy MiniOS và hiển thị kết quả cấp phát bộ nhớ.

## 🔁 Thoát khỏi QEMU
- Nhấn `Ctrl + Alt + G` để thoát chuột
- Nhấn `Ctrl + C` trong terminal để tắt

Chúc bạn thành công!
