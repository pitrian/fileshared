[org 0x7c00]
mov ah, 0x0e

mov si, msg
.print:
    lodsb
    or al, al
    jz halt
    int 0x10
    jmp .print
halt:
    cli
    hlt

msg db "Booting MiniOS with Custom Memory Allocator...", 0

times 510 - ($ - $$) db 0
dw 0xaa55
