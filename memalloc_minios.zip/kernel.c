void putc(char c) {
    volatile char *video = (volatile char*)0xb8000;
    static int pos = 0;
    video[pos++] = c;
    video[pos++] = 0x07;
}

void puts(const char *s) {
    while (*s) putc(*s++);
}

#define HEAP_SIZE 65536
char heap[HEAP_SIZE];
int used[HEAP_SIZE];

void* my_malloc(int size) {
    for (int i = 0; i < HEAP_SIZE - size; ++i) {
        int found = 1;
        for (int j = 0; j < size; ++j) {
            if (used[i + j]) {
                found = 0;
                break;
            }
        }
        if (found) {
            for (int j = 0; j < size; ++j) used[i + j] = 1;
            return &heap[i];
        }
    }
    return 0;
}

void my_free(void* ptr, int size) {
    int offset = (char*)ptr - heap;
    for (int i = 0; i < size; ++i)
        used[offset + i] = 0;
}

void kernel_main() {
    puts("MiniOS Booted!\n");
    char* mem1 = my_malloc(10);
    if (mem1) puts("Allocated 10 bytes\n");
    char* mem2 = my_malloc(20);
    if (mem2) puts("Allocated 20 bytes\n");
    my_free(mem1, 10);
    puts("Freed 10 bytes\n");
    while (1);
}
