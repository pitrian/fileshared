#ifndef MEMALLOC_H
#define MEMALLOC_H

#include <stdint.h>
#include <stddef.h>

void* my_malloc(size_t size);
void my_free(void* ptr);

#endif