#include "memalloc.h"

#define HEAP_SIZE 1024 * 1024  // 1 MB

static uint8_t heap[HEAP_SIZE];
static size_t offset = 0;

void* my_malloc(size_t size) {
    if (offset + size > HEAP_SIZE) return NULL;
    void* ptr = &heap[offset];
    offset += size;
    return ptr;
}

void my_free(void* ptr) {
    // Simple allocator doesn't support freeing individual blocks
}