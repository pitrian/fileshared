[org 0x7c00]
mov ah, 0x0e
mov si, welcome
call print_string
jmp $

print_string:
    .next_char:
        lodsb
        or al, al
        jz .done
        int 0x10
        jmp .next_char
    .done:
        ret

welcome db "Booting MiniOS with Custom Memory Allocator...", 0

times 510 - ($ - $$) db 0
dw 0xAA55