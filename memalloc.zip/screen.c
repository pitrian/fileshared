#include "screen.h"
#include <stdint.h>

#define VIDEO_MEMORY (uint16_t*)0xB8000
#define WHITE_ON_BLACK 0x0F

void print(const char* str) {
    uint16_t* video = VIDEO_MEMORY;
    while (*str) {
        *video++ = (*str++ | WHITE_ON_BLACK << 8);
    }
}