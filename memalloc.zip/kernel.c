void kmain() {
    print("MiniOS Kernel with Memory Allocator\n");

    void* ptr1 = my_malloc(64);
    print("Allocated 64 bytes\n");

    void* ptr2 = my_malloc(128);
    print("Allocated 128 bytes\n");

    my_free(ptr1);
    print("Freed first block\n");

    my_free(ptr2);
    print("Freed second block\n");
}